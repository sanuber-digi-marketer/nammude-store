# Nammude Store Demo

Mobile-friendly static grocery ordering prototype.

## GitHub Pages deployment
1. Create a **public** repository named `nammude-store-demo`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then Save.
6. After publishing, your site URL will look like:
   `https://YOUR-USERNAME.github.io/nammude-store-demo/`

This is a front-end demo only. It is not connected to real shop inventory, accounts, saved orders, notifications, or payments.
